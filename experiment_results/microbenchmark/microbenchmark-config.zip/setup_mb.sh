#!/bin/bash

export CLOUDSDK_CORE_PROJECT=masterarbeit-353409
export CLOUDSDK_COMPUTE_REGION=europe-west1
export CLOUDSDK_COMPUTE_ZONE=europe-west1-b
export GOOGLE_APPLICATION_CREDENTIALS="/home/njapke/application_default_credentials.json"

full_mb_flags='--microbenchmark-exclude-filter ^chi.*$'

sev=0
# A/A test
./cloud-benchmark-conductor mb $full_mb_flags --microbenchmark-v1 perf-issue-clean-path-sev-0 --microbenchmark-v2 perf-issue-clean-path --microbenchmark-env SEVERITY=$sev
./cloud-benchmark-conductor cleanup
./cloud-benchmark-conductor mb $full_mb_flags --microbenchmark-v1 perf-issue-request-id-sev-0 --microbenchmark-v2 perf-issue-request-id --microbenchmark-env SEVERITY=$sev
./cloud-benchmark-conductor cleanup
./cloud-benchmark-conductor mb $full_mb_flags --microbenchmark-v1 perf-issue-basic-auth-sev-0 --microbenchmark-v2 perf-issue-basic-auth --microbenchmark-env SEVERITY=$sev
./cloud-benchmark-conductor cleanup

# severity in powers of 2
for i in {0..11}
do
	sev=$((2**i))
	echo "Severity is $sev"
	#./cloud-benchmark-conductor config $full_mb_flags
	./cloud-benchmark-conductor mb $full_mb_flags --microbenchmark-v1 perf-issue-clean-path-sev-0 --microbenchmark-v2 perf-issue-clean-path --microbenchmark-env SEVERITY=$sev
	./cloud-benchmark-conductor cleanup
	./cloud-benchmark-conductor mb $full_mb_flags --microbenchmark-v1 perf-issue-request-id-sev-0 --microbenchmark-v2 perf-issue-request-id --microbenchmark-env SEVERITY=$sev
	./cloud-benchmark-conductor cleanup
	./cloud-benchmark-conductor mb $full_mb_flags --microbenchmark-v1 perf-issue-basic-auth-sev-0 --microbenchmark-v2 perf-issue-basic-auth --microbenchmark-env SEVERITY=$sev
	./cloud-benchmark-conductor cleanup
done

